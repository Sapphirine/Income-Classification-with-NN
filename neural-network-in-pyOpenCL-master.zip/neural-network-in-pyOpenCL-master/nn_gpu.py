#!/usr/bin/env python

import numpy as np
from urllib import urlretrieve
import cPickle as pickle
import os
import gzip
import time
from scipy import signal

import pyopencl as cl
import pyopencl.array
import csv



## Select the desired OpenCL platform:
NAME = 'NVIDIA CUDA'
platforms = cl.get_platforms()
devs = None
for platform in platforms:
    if platform.name == NAME:
        devs = platform.get_devices()

# Set up a command queue:
ctx = cl.Context(devs[0:1])
queue = cl.CommandQueue(ctx)

#dot product and sigmoid kernel
func_sigm_dot = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global const float *b, __global float *c, const unsigned int P, const unsigned int Q, const unsigned int R) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    unsigned int k;
    
    float temp = 0.0f;
    
    for (k = 0; k < Q; k++)
        temp += a[i*Q + k] * b[k*R + j];
    
    temp = 1/(1+exp(-temp));
    
    c[i*R+j] = temp;
    
    }
    """).build().func

func_sigm_dot.set_scalar_arg_dtypes([None, None, None, np.uint32, np.uint32, np.uint32])

# Define the concatenate  OpenCL kernel:

func_concatenate = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global const float *b, __global float *c, const unsigned int col_a, const unsigned int col_b) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    unsigned int k = get_global_id(2);
    
    
    // ith row jth column in a is ith row jth column in c
    // ith row kth column in b is ith row (col_a+k)th column in c
    c[i * (col_a+col_b) + j] = a[i*col_a+j];
    c[i * (col_a+col_b) + (col_a+k)] = b[i*col_b+k];
    
    }
    """).build().func

func_concatenate.set_scalar_arg_dtypes([None, None, None, np.uint32, np.uint32])


#---------------------------------------------------------------------------------------
# Define the minus OpenCL kernel:

func_minus = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global const float *b, __global float *c, const unsigned int col) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    
    c[i*col+j] = a[i*col+j] - b[i*col+j];
    
    }
    """).build().func

func_minus.set_scalar_arg_dtypes([None, None, None, np.uint32])

# Define the transpose function  OpenCL kernel:
func_transpose = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global float *b, const unsigned int col_a, const unsigned int row_a) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    
    b[j*row_a + i] = a[i*col_a + j];
    
    }
    """).build().func

func_transpose.set_scalar_arg_dtypes([None, None, np.uint32,np.uint32])


# Define the multiply OpenCL kernel:

func_mul = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global const float *b, __global float *c, const unsigned int w) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    
    c[i*w+j] = a[i*w+j] * b[i*w+j];
    
    
    }
    """).build().func

func_mul.set_scalar_arg_dtypes([None, None, None, np.uint32])

#---------------------------------------------------------------------------------------
# Define the index OpenCL kernel:

func_index = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global float *b, const unsigned int w) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    
    b[i*w+j]=a[i*(w+1)+j+1];
    
    
    
    }
    """).build().func

func_index.set_scalar_arg_dtypes([None, None, np.uint32])

# Define the dot product OpenCL kernel:

func_dot = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global const float *b, __global float *c, const unsigned int P, const unsigned int Q, const unsigned int R) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    unsigned int k;
    
    float temp = 0.0f;
    
    for (k = 0; k < Q; k++)
    temp += a[i*Q + k] * b[k*R + j];
    
    c[i*R+j] = temp;
    
    }
    """).build().func

func_dot.set_scalar_arg_dtypes([None, None, None, np.uint32, np.uint32, np.uint32])


# Define the divide OpenCL kernel:

func_divide_50000 = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global float *b, const unsigned int w) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    
    b[i*w+j]=a[i*w+j] / 50000;
    
    
    
    }
    """).build().func

func_divide_50000.set_scalar_arg_dtypes([None, None, np.uint32])

# Define the plus weight OpenCL kernel:

func_plus_weight = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global float *b, __global float *c, const unsigned int w, const unsigned int weight) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    
    c[i*w+j]=a[i*w+j] + b[i*w+j]*weight/10000;
    
    
    
    }
    """).build().func

func_plus_weight.set_scalar_arg_dtypes([None, None,None, np.uint32,np.uint32])


# Define the mul scalar OpenCL kernel:

func_mul_scalar = cl.Program(ctx, """
    __kernel void func(__global const float *a, __global float *b, const unsigned int w,const unsigned int weight) {
    
    unsigned int i = get_global_id(0);
    unsigned int j = get_global_id(1);
    
    b[i*w+j]=a[i*w+j] * weight / 10;
    
    
    
    }
    """).build().func

func_mul_scalar.set_scalar_arg_dtypes([None, None, np.uint32,np.uint32])

#------------------------------------------------------------------------------------------

#function used to load dataset
def load_dataset():
    url = 'http://deeplearning.net/data/mnist/mnist.pkl.gz'
    filename = 'mnist.pkl.gz'
    if not os.path.exists(filename):
        print("Downloading MNIST dataset...")
        urlretrieve(url, filename)

    with gzip.open(filename, 'rb') as f:
        data = pickle.load(f)

    X_train, y_train = data[0]
    X_val, y_val = data[1]
    X_test, y_test = data[2]

    X_train = X_train.reshape((-1, 1, 28, 28))
    X_val = X_val.reshape((-1, 1, 28, 28))
    X_test = X_test.reshape((-1, 1, 28, 28))

    y_train = y_train.astype(np.uint8)
    y_val = y_val.astype(np.uint8)
    y_test = y_test.astype(np.uint8)

    return (X_train, y_train, X_val, y_val, X_test, y_test)

#structure designed to store net parameters
class net_para(object):
    def __init__(self,learning_rate, momentum, scale, weight_penalty_L2):
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.scale = scale
        self.weight_penalty_L2 = weight_penalty_L2


def sigm(input):                                        #suggested
    return 1/(1+np.exp(-input))

#structure designed to store net parameters
class net_para(object):
    def __init__(self,learning_rate, momentum, scale, weight_penalty_L2):
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.scale = scale
        self.weight_penalty_L2 = weight_penalty_L2




#feedforward the data through the entire network
def nn_ff(data, Y, W1, W2):
    m = data.shape[0]
    data = np.concatenate((np.ones((m,1)), data), axis = 1)
    
    
    #feedforward pass 1st layer: sigmoid layer
    nn_a_1 = data
    nn_a_2 = sigm(np.dot(nn_a_1, W1.T))
    nn_a_2 = np.concatenate((np.ones((m,1)), nn_a_2), axis = 1)
    
    #feedforward pass 2nd layer: sigmoid layer
    nn_a_3 = sigm( np.dot(nn_a_2, W2.T ) )              #suggested
    
    #error and loss
    nn_e = Y - nn_a_3
    
    nn_L = 0.5 * np.sum( np.power(nn_e,2) ) / m         #suggested
    print "loss: ", nn_L
    
    return (nn_e, nn_a_3, nn_a_2, nn_a_1)

#test a trained network
def nn_test(W1, W2, X_test, Y_test):
    nn_e, nn_a_3, nn_a_2, nn_a_1 = nn_ff(X_test, Y_test, W1, W2)
    predicted = nn_a_3.argmax(axis=1)
    label = Y_test.argmax(axis=1)
    accuracy = (np.sum(predicted == label) + 0.) / label.shape[0]
    
    return accuracy



#------------------------------------------------------------------------------------------------
#loading training and testing data
X_train, y_train, X_val, y_val, X_test, y_test = load_dataset()

# num * dimension
X_train = X_train.reshape(50000,28*28)
temp = np.zeros(X_train.shape).astype(np.float32)
X_train = temp
X_test = X_test.reshape(10000,28*28)
temp = np.zeros(X_test.shape).astype(np.float32)
X_test = temp

Y_train = np.zeros((y_train.shape[0],10)).astype(np.float32)
for i in xrange(y_train.shape[0]):
    Y_train[i,y_train[i]] = 1

Y_test = np.zeros((y_test.shape[0],10)).astype(np.float32)
for i in xrange(y_test.shape[0]):
    Y_test[i,y_test[i]] = 1


#------------------------------------------------------------------------------------------------
#initialize network
start_local = time.time()

num_hidden = 200

np.random.seed(0)

W1 = ( np.random.uniform(0,1,(num_hidden, 785)).astype(np.float32) - 0.5 ) * 2. * 4. * np.sqrt(6. / (784. + num_hidden))
vW_1 = np.zeros(W1.shape).astype(np.float32)
W2 = ( np.random.uniform(0,1,(10, num_hidden + 1)).astype(np.float32) - 0.5 ) * 2. * 4. * np.sqrt(6. / (10. + num_hidden))
vW_2 = np.zeros(W2.shape).astype(np.float32)

#training parameters
num_epochs = 4
num_sample = 50000

X_train = X_train[0:num_sample,:]
Y_train = Y_train[0:num_sample,:]


#create some gpu arrays for training
X_gpu = cl.array.to_device(queue, X_train)
Y_gpu = cl.array.to_device(queue, Y_train)

bias = np.ones((num_sample,1)).astype(np.float32)
bias_gpu = cl.array.to_device(queue, bias)

data = np.concatenate((bias, X_train), axis = 1)
nn_a_1_gpu = cl.array.to_device(queue, data)

W1_gpu = cl.array.to_device(queue, W1)
W2_gpu = cl.array.to_device(queue, W2)
vW_1_gpu = cl.array.to_device(queue, vW_1)
vW_2_gpu = cl.array.to_device(queue, vW_2)

temp = np.ones((num_sample,10)).astype(np.float32)
one_minus_a_3 = cl.array.to_device(queue, temp)

temp = np.ones((num_sample,num_hidden+1)).astype(np.float32)
one_minus_a_2 = cl.array.to_device(queue, temp)

temp = np.zeros((W1.shape[0],1)).astype(np.float32)
term_1_gpu = cl.array.to_device(queue, temp)

temp = np.zeros((W2.shape[0],1)).astype(np.float32)
term_1_gpu_2 = cl.array.to_device(queue, temp)


#initialize gpu array
W1_t_gpu = cl.array.empty(queue, (W1_gpu.shape[1], W1_gpu.shape[0]), data.dtype)
W2_t_gpu = cl.array.empty(queue, (W2_gpu.shape[1], W2_gpu.shape[0]), data.dtype)

nn_a_2_gpu = cl.array.empty(queue, (nn_a_1_gpu.shape[0], W1_t_gpu.shape[1]), data.dtype)

nn_a_2_con_gpu = cl.array.empty(queue, (bias_gpu.shape[0], 1+num_hidden), data.dtype)

nn_a_3_gpu = cl.array.empty(queue, (nn_a_2_con_gpu.shape[0], W2_t_gpu.shape[1]), data.dtype)

nn_e_gpu = cl.array.empty(queue, (nn_a_3_gpu.shape), data.dtype)

nn_a_3_minused_gpu = cl.array.empty(queue, (nn_a_3_gpu.shape), data.dtype)

nn_a_3_muled_gpu = cl.array.empty(queue, (nn_a_3_gpu.shape), data.dtype)

nn_a_2_minused_gpu = cl.array.empty(queue, (nn_a_2_con_gpu.shape), data.dtype)

d_act_gpu = cl.array.empty(queue, (nn_a_2_con_gpu.shape), data.dtype)

d_3_gpu = cl.array.empty(queue, (nn_a_3_gpu.shape), data.dtype)

d_3_doted_gpu = cl.array.empty(queue, (d_3_gpu.shape[0],W2_gpu.shape[1]), data.dtype)

d_2_gpu = cl.array.empty(queue, (d_3_doted_gpu.shape[0],d_3_doted_gpu.shape[1]), data.dtype)

d_2_index_gpu = cl.array.empty(queue, (d_2_gpu.shape[0],d_2_gpu.shape[1]-1), data.dtype)

d_2_index_t_gpu = cl.array.empty(queue, (d_2_index_gpu.shape[1],d_2_index_gpu.shape[0]), data.dtype)

d_2_t_doted_gpu = cl.array.empty(queue, (d_2_index_t_gpu.shape[0],nn_a_1_gpu.shape[1]), data.dtype)

nn_dW_1_gpu = cl.array.empty(queue, (num_hidden,784), data.dtype)

d_3_t_gpu = cl.array.empty(queue, (d_3_gpu.shape[1],d_3_gpu.shape[0]), data.dtype)

d_3_t_doted_gpu = cl.array.empty(queue, (d_3_t_gpu.shape[0],nn_a_2_con_gpu.shape[1]), data.dtype)

nn_dW_2_gpu = cl.array.empty(queue, (d_3_t_doted_gpu.shape[0],d_3_t_doted_gpu.shape[1]), data.dtype)

term_2_gpu = cl.array.empty(queue, (W1_gpu.shape[0],W1_gpu.shape[1]-1), data.dtype)

term_con = cl.array.empty(queue, (term_1_gpu.shape[0],term_1_gpu.shape[1]+term_2_gpu.shape[1]), data.dtype)

dW_gpu = cl.array.empty(queue, (nn_dW_1_gpu.shape[0],nn_dW_1_gpu.shape[1]), data.dtype)

dW_gpu_2 = cl.array.empty(queue, (dW_gpu.shape), data.dtype)

term_2_gpu_2 = cl.array.empty(queue, (W2_gpu.shape[0],num_hidden), data.dtype)

term_con_2 = cl.array.empty(queue, (term_1_gpu_2.shape[0],term_1_gpu_2.shape[1]+term_2_gpu_2.shape[1]), data.dtype)

dW_gpu_l2 = cl.array.empty(queue, (nn_dW_2_gpu.shape[0],nn_dW_2_gpu.shape[1]), data.dtype)

dW_gpu_2_l2 = cl.array.empty(queue, (dW_gpu_l2.shape), data.dtype)



times_local = time.time() - start_local
print "initialization time (s): ", times_local

#train the network
start = time.time()
for ite in xrange(num_epochs):
    
    print "at iteration ", ite, " :"
    
    
    #feedforward data -----------------------------------------------------------------------------
    start_local = time.time()
    
    func_transpose(queue,(W1_gpu.shape[0],W1_gpu.shape[1]),None,W1_gpu.data,W1_t_gpu.data,W1_gpu.shape[1],W1_gpu.shape[0])
    func_transpose(queue,(W2_gpu.shape[0],W2_gpu.shape[1]),None,W2_gpu.data,W2_t_gpu.data,W2_gpu.shape[1],W2_gpu.shape[0])

    #feedforward pass 1st layer: sigmoid layer
    func_sigm_dot(queue,(nn_a_1_gpu.shape[0], W1_t_gpu.shape[1]),None,nn_a_1_gpu.data,W1_t_gpu.data,nn_a_2_gpu.data,nn_a_1_gpu.shape[0],nn_a_1_gpu.shape[1], W1_t_gpu.shape[1])

    func_concatenate(queue,(bias_gpu.shape[0],bias_gpu.shape[1],nn_a_2_gpu.shape[1]),None,bias_gpu.data,nn_a_2_gpu.data,nn_a_2_con_gpu.data,bias_gpu.shape[1],nn_a_2_gpu.shape[1])

    func_sigm_dot(queue,(nn_a_2_con_gpu.shape[0],W2_t_gpu.shape[1]),None,nn_a_2_con_gpu.data,W2_t_gpu.data,nn_a_3_gpu.data,nn_a_2_con_gpu.shape[0],nn_a_2_con_gpu.shape[1],W2_t_gpu.shape[1])

    func_minus(queue,(Y_gpu.shape[0],Y_gpu.shape[1]),None,Y_gpu.data,nn_a_3_gpu.data,nn_e_gpu.data,Y_gpu.shape[1])

    times_local = time.time() - start_local
    print "             forward time (s):       ", times_local
    
    #backpropagate error -----------------------------------------------------------------------------
    start_local = time.time()

    func_minus(queue,(nn_a_3_gpu.shape[0],nn_a_3_gpu.shape[1]),None,nn_a_3_gpu.data,one_minus_a_3.data,nn_a_3_minused_gpu.data,nn_a_3_gpu.shape[1])

    func_mul(queue,(nn_a_3_gpu.shape[0],nn_a_3_gpu.shape[1]),None,nn_a_3_gpu.data,nn_a_3_minused_gpu.data,nn_a_3_muled_gpu.data,nn_a_3_gpu.shape[1])

    func_mul(queue,(nn_e_gpu.shape[0],nn_e_gpu.shape[1]),None,nn_e_gpu.data,nn_a_3_muled_gpu.data,d_3_gpu.data,nn_e_gpu.shape[1])

    func_minus(queue,(nn_a_2_con_gpu.shape[0],nn_a_2_con_gpu.shape[1]),None,one_minus_a_2.data,nn_a_2_con_gpu.data,nn_a_2_minused_gpu.data,nn_a_2_con_gpu.shape[1])


    func_mul(queue,(nn_a_2_con_gpu.shape[0],nn_a_2_con_gpu.shape[1]),None,nn_a_2_con_gpu.data,nn_a_2_minused_gpu.data,d_act_gpu.data,nn_a_2_con_gpu.shape[1])

    func_dot(queue,(d_3_gpu.shape[0],W2_gpu.shape[1]),None,d_3_gpu.data,W2_gpu.data,d_3_doted_gpu.data,d_3_gpu.shape[0],d_3_gpu.shape[1],W2_gpu.shape[1])


    func_mul(queue,(d_2_gpu.shape[0],d_2_gpu.shape[1]),None,d_3_doted_gpu.data,d_act_gpu.data,d_2_gpu.data,d_3_doted_gpu.shape[1])
    
   
    func_index(queue,(d_2_index_gpu.shape[0],d_2_index_gpu.shape[1]),None,d_2_gpu.data,d_2_index_gpu.data,d_2_index_gpu.shape[1])


    func_transpose(queue,(d_2_index_gpu.shape[0],d_2_index_gpu.shape[1]),None,d_2_index_gpu.data,d_2_index_t_gpu.data,d_2_index_gpu.shape[1],d_2_index_gpu.shape[0])


    func_dot(queue,(d_2_t_doted_gpu.shape[0],d_2_t_doted_gpu.shape[1]),None,d_2_index_t_gpu.data,nn_a_1_gpu.data,d_2_t_doted_gpu.data,d_2_index_t_gpu.shape[0],d_2_index_t_gpu.shape[1],nn_a_1_gpu.shape[1])


    func_divide_50000(queue,(nn_dW_1_gpu.shape[0],nn_dW_1_gpu.shape[1]),None,d_2_t_doted_gpu.data,nn_dW_1_gpu.data,d_2_t_doted_gpu.shape[1])


    func_transpose(queue,(d_3_gpu.shape[0],d_3_gpu.shape[1]),None,d_3_gpu.data,d_3_t_gpu.data,d_3_gpu.shape[1],d_3_gpu.shape[0])


    func_dot(queue,(d_3_t_doted_gpu.shape[0],d_3_t_doted_gpu.shape[1]),None,d_3_t_gpu.data,nn_a_2_con_gpu.data,d_3_t_doted_gpu.data,d_3_t_gpu.shape[0],d_3_t_gpu.shape[1],nn_a_2_con_gpu.shape[1])


    func_divide_50000(queue,(d_3_t_doted_gpu.shape[0],d_3_t_doted_gpu.shape[1]),None,d_3_t_doted_gpu.data,nn_dW_2_gpu.data,d_3_t_doted_gpu.shape[1])
    

    
    times_local = time.time() - start_local
    print "             backpropagate time (s): ", times_local
    
    
    #update weights-----------------------------------------------------------------------------
    #
    start_local = time.time()
    
    #1st layer

    func_index(queue,(term_2_gpu.shape[0],term_2_gpu.shape[1]),None,W1_gpu.data,term_2_gpu.data,term_2_gpu.shape[1])


    func_concatenate(queue,(term_1_gpu.shape[0],term_1_gpu.shape[1],term_2_gpu.shape[1]),None,term_1_gpu.data,term_2_gpu.data,term_con.data,term_1_gpu.shape[1],term_2_gpu.shape[1])


    func_plus_weight(queue,(nn_dW_1_gpu.shape[0],nn_dW_1_gpu.shape[1]),None,nn_dW_1_gpu.data,term_con.data,dW_gpu.data,nn_dW_1_gpu.shape[1],1)


    func_mul_scalar(queue,(dW_gpu.shape[0],dW_gpu.shape[1]),None,dW_gpu.data,dW_gpu_2.data,dW_gpu.shape[1],1)
    
    
    func_plus_weight(queue,(dW_gpu_2.shape[0],dW_gpu_2.shape[1]),None,dW_gpu_2.data,vW_1_gpu.data,vW_1_gpu.data,dW_gpu_2.shape[1],5000)


    
    func_minus(queue,(W1_gpu.shape[0],W1_gpu.shape[1]),None,W1_gpu.data,vW_1_gpu.data,W1_gpu.data,W1_gpu.shape[1])


    #update 2nd layer


    func_index(queue,(term_2_gpu_2.shape[0],term_2_gpu_2.shape[1]),None,W2_gpu.data,term_2_gpu_2.data,term_2_gpu_2.shape[1])

    func_concatenate(queue,(term_1_gpu_2.shape[0],term_1_gpu_2.shape[1],term_2_gpu_2.shape[1]),None,term_1_gpu_2.data,term_2_gpu_2.data,term_con_2.data,term_1_gpu_2.shape[1],term_2_gpu_2.shape[1])


    func_plus_weight(queue,(dW_gpu_l2.shape[0],dW_gpu_l2.shape[1]),None,nn_dW_2_gpu.data,term_con_2.data,dW_gpu_l2.data,dW_gpu_l2.shape[1],1)


    func_mul_scalar(queue,(dW_gpu_l2.shape[0],dW_gpu_l2.shape[1]),None,dW_gpu_l2.data,dW_gpu_2_l2.data,dW_gpu_l2.shape[1],1)



    func_plus_weight(queue,(dW_gpu_2_l2.shape[0],dW_gpu_2_l2.shape[1]),None,dW_gpu_2_l2.data,vW_2_gpu.data,vW_2_gpu.data,dW_gpu_2_l2.shape[1],5000)
    

    func_minus(queue,(W2_gpu.shape[0],W2_gpu.shape[1]),None,W2_gpu.data,vW_2_gpu.data,W2_gpu.data,W2_gpu.shape[1])



    times_local = time.time() - start_local
    print "             update time (s):        ", times_local



times = time.time() - start

#test the network

W1 = W1_gpu.get()
W2 = W2_gpu.get()

acc = nn_test(W1, W2, X_test, Y_test)

print "accuracy is ", acc
print "each epoch takes (s) ", (times + 0.) / num_epochs

print "", devs













