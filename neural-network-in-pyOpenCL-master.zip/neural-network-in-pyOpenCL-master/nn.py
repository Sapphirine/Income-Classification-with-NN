import numpy as np
from urllib import urlretrieve
import cPickle as pickle
import os
import gzip
import time


#function used to load dataset
def load_dataset():
    url = 'http://deeplearning.net/data/mnist/mnist.pkl.gz'
    filename = 'mnist.pkl.gz'
    if not os.path.exists(filename):
        print("Downloading MNIST dataset...")
        urlretrieve(url, filename)

    with gzip.open(filename, 'rb') as f:
        data = pickle.load(f)

    X_train, y_train = data[0]
    X_val, y_val = data[1]
    X_test, y_test = data[2]

    X_train = X_train.reshape((-1, 1, 28, 28))
    X_val = X_val.reshape((-1, 1, 28, 28))
    X_test = X_test.reshape((-1, 1, 28, 28))

    y_train = y_train.astype(np.uint8)
    y_val = y_val.astype(np.uint8)
    y_test = y_test.astype(np.uint8)

    return (X_train, y_train, X_val, y_val, X_test, y_test)

#structure designed to store net parameters
class net_para(object):
    def __init__(self,learning_rate, momentum, scale, weight_penalty_L2):
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.scale = scale
        self.weight_penalty_L2 = weight_penalty_L2

#sigmoid function
def sigm(input):                                        #suggested
    return 1/(1+np.exp(-input))


#feedforward the data through the entire network
def nn_ff(data, Y, W1, W2):
    m = data.shape[0]
    data = np.concatenate((np.ones((m,1)), data), axis = 1)


    #feedforward pass 1st layer: sigmoid layer
    nn_a_1 = data
    nn_a_2 = sigm(np.dot(nn_a_1, W1.T))
    nn_a_2 = np.concatenate((np.ones((m,1)), nn_a_2), axis = 1)

    #feedforward pass 2nd layer: sigmoid layer
    nn_a_3 = sigm( np.dot(nn_a_2, W2.T ) )

    #error and loss
    nn_e = Y - nn_a_3

    nn_L = 0.5 * np.sum( np.power(nn_e,2) ) / m
    print "loss: ", nn_L

    return (nn_e, nn_a_3, nn_a_2, nn_a_1,nn_L)


#backpropagate the errors through the entire network
def nn_bp(nn_e, nn_a_3, nn_a_2, nn_a_1, W2):

    d_3 = - np.multiply(nn_e, np.multiply(nn_a_3, 1 - nn_a_3))
    

    #derivative of the activation function
    d_act = np.multiply(nn_a_2, 1 - nn_a_2)

    #backpropagate the first derivatives
    #layer 2
    d_2 = np.multiply( np.dot(d_3, W2), d_act)

    temp = d_2[:,1:]
    nn_dW_1 = np.divide( np.dot(temp.T, nn_a_1), 0. + d_2.shape[0])

    nn_dW_2 = np.divide( np.dot(d_3.T, nn_a_2), 0. + d_3.shape[0])

    return (nn_dW_1, nn_dW_2)

#update the weights in the entire network
def nn_update(para, nn_dW_1, W1, vW_1, nn_dW_2, W2, vW_2):
    #update 1st layer

    term_1 = np.zeros((W1.shape[0],1))
    term_2 = W1[:,1:]
    dW = nn_dW_1 + np.multiply( np.concatenate((term_1,term_2), axis = 1) ,para.weight_penalty_L2)      #suggested
    dW = np.multiply(dW, para.learning_rate)        #suggested

    vW_1 = dW + np.multiply(vW_1, para.momentum)    #suggested
    dW = vW_1

    W1 = W1 - dW

    #update 2nd layer
    term_1 = np.zeros((W2.shape[0],1))
    term_2 = W2[:,1:]
    dW = nn_dW_2 + np.multiply( np.concatenate((term_1,term_2), axis = 1) ,para.weight_penalty_L2)      #suggested
    dW = np.multiply(dW, para.learning_rate)        #suggested

    vW_2 = dW + np.multiply(vW_2, para.momentum)    #suggested
    dW = vW_2

    W2 = W2 - dW

    return (W1, W2, vW_1, vW_2)


#test a trained network
def nn_test(W1, W2, X_test, Y_test):
    nn_e, nn_a_3, nn_a_2, nn_a_1, nn_loss = nn_ff(X_test, Y_test, W1, W2)
    predicted = nn_a_3.argmax(axis=1)
    label = Y_test.argmax(axis=1)
    accuracy = (np.sum(predicted == label) + 0.) / label.shape[0]

    return accuracy



#------------------------------------------------------------------------------------------------
#loading training and testing data
X_train, y_train, X_val, y_val, X_test, y_test = load_dataset()

# num * dimension
X_train = X_train.reshape(50000,28*28)
X_test = X_test.reshape(10000,28*28)

Y_train = np.zeros((y_train.shape[0],10))
for i in xrange(y_train.shape[0]):
    Y_train[i,y_train[i]] = 1

Y_test = np.zeros((y_test.shape[0],10))
for i in xrange(y_test.shape[0]):
    Y_test[i,y_test[i]] = 1



#------------------------------------------------------------------------------------------------
#initialize network

num_hidden = 200

np.random.seed(0)

W1 = ( np.random.uniform(0,1,(num_hidden, 785)) - 0.5 ) * 2. * 4. * np.sqrt(6. / (784. + num_hidden))
vW_1 = np.zeros(W1.shape)
W2 = ( np.random.uniform(0,1,(10, num_hidden + 1)) - 0.5 ) * 2. * 4. * np.sqrt(6. / (10. + num_hidden))
vW_2 = np.zeros(W2.shape)

#training parameters
para = net_para(learning_rate = 0.1, momentum = 0.5, scale = 1, weight_penalty_L2 = 0.0001)
num_epochs = 1000


loss = np.zeros((1,500000))
counter = -1

test_acc = np.zeros((1,500))


#train the network
start = time.time()
for ite in xrange(num_epochs):
    
    counter = counter + 1

    print "at iteration ", ite, " :"
    
    #feedforward data
    start_local = time.time()
    nn_e, nn_a_3, nn_a_2, nn_a_1, nn_loss = nn_ff(X_train, Y_train, W1, W2)
    times_local = time.time() - start_local
    print "             forward time (s):       ", times_local

    #backpropagate error
    start_local = time.time()
    nn_dW_1, nn_dW_2 = nn_bp(nn_e, nn_a_3, nn_a_2, nn_a_1, W2)
    times_local = time.time() - start_local
    print "             backpropagate time (s): ", times_local

    #update weights
    start_local = time.time()
    W1, W2, vW_1, vW_2 = nn_update(para, nn_dW_1, W1, vW_1, nn_dW_2, W2, vW_2)
    times_local = time.time() - start_local
    print "             update time (s):        ", times_local

    acc = nn_test(W1, W2, X_test, Y_test)
    test_acc[0,counter] = acc
    loss[0,counter] = nn_loss


times = time.time() - start

#test the network

acc = nn_test(W1, W2, X_test, Y_test)
print "accuracy is ", acc
print "each epoch takes (s) ", (times + 0.) / num_epochs

name1 = 'acc_' + str(num_hidden) + '.txt'
name2 = 'loss_' + str(num_hidden) + '.txt'
np.savetxt(name1,test_acc)
np.savetxt(name2,loss)









