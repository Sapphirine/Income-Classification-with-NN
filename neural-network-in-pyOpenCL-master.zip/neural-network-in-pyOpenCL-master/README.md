# neural-network-in-pyOpenCL
GPU implementation of neural network and convolutional neural network using pyOpenCL.

In the same directory, there are four python files which are desinged for handwritten digit recognition:

    1. nn.py                :   python version of traditional 3 layer neural network
    2. nn_gpu.py            :   pyopencl version of traditional 3 layer neural network
    3. cnn.py               :   python version of convolutional neural network
    4. cnn_gpu.py           :   pyopencl version of convolutional neural network
