import numpy as np
from urllib import urlretrieve
import cPickle as pickle
import os
import gzip
import time
from scipy import signal


#------------------------------------------------------------------------------------------------


#structure designed to store net parameters
class net_para(object):
    def __init__(self,l_2_outputmaps,l_2_kernelsize,l_3_scale,l_4_outputmaps,l_4_kernelsize,l_5_scale):
        self.l_2_outputmaps = l_2_outputmaps
        self.l_2_kernelsize = l_2_kernelsize
        self.l_3_scale = l_3_scale
        self.l_4_outputmaps = l_4_outputmaps
        self.l_4_kernelsize = l_4_kernelsize
        self.l_5_scale = l_5_scale

#structure designed to store net weights
class net_weights(object):
    def __init__(self,net_l_2_k,net_l_2_b,net_l_3_b,net_l_4_k,net_l_4_b,net_l_5_b,net_ff_b,net_ff_W):
        self.net_l_2_k = net_l_2_k
        self.net_l_2_b = net_l_2_b
        self.net_l_3_b = net_l_3_b
        self.net_l_4_k = net_l_4_k
        self.net_l_4_b = net_l_4_b
        self.net_l_5_b = net_l_5_b
        self.net_ff_b = net_ff_b
        self.net_ff_W = net_ff_W

#structure designed to store net outputs
class net_layer_output(object):
    def __init__(self,l_2_a,l_3_a,l_4_a,l_5_a,l_concatenated,net_l_output):
        self.l_2_a = l_2_a
        self.l_3_a = l_3_a
        self.l_4_a = l_4_a
        self.l_5_a = l_5_a
        self.l_concatenated = l_concatenated
        self.net_l_output = net_l_output

#structure designed to store net derivatives
class net_dev(object):
    def __init__(self,l_2_dk,l_2_db,l_4_dk,l_4_db,dff_W,dff_b):
        self.l_2_dk = l_2_dk
        self.l_2_db = l_2_db
        self.l_4_dk = l_4_dk
        self.l_4_db = l_4_db
        self.dff_W = dff_W
        self.dff_b = dff_b



#------------------------------------------------------------------------------------------------

#function used to load dataset
def load_dataset():
    url = 'http://deeplearning.net/data/mnist/mnist.pkl.gz'
    filename = 'mnist.pkl.gz'
    if not os.path.exists(filename):
        print("Downloading MNIST dataset...")
        urlretrieve(url, filename)
    
    with gzip.open(filename, 'rb') as f:
        data = pickle.load(f)
    
    X_train, y_train = data[0]
    X_val, y_val = data[1]
    X_test, y_test = data[2]

    X_train = X_train.reshape((-1, 1, 28, 28))
    X_val = X_val.reshape((-1, 1, 28, 28))
    X_test = X_test.reshape((-1, 1, 28, 28))
    
    y_train = y_train.astype(np.uint8)
    y_val = y_val.astype(np.uint8)
    y_test = y_test.astype(np.uint8)
    
    return (X_train, y_train, X_val, y_val, X_test, y_test)


#sigmoid function
def sigm(input):
    return 1/(1+np.exp(-input))


def flip_all(X_input):
    num = X_input.shape[2]
    local_X = np.zeros(X_input.shape)
    for i in xrange(0,num):
        temp = X_input[:,:,i]
        temp = temp[::-1]
        temp = np.fliplr(temp)
        local_X[:,:,i] = temp

    output = np.zeros((X_input.shape))
    for i in xrange(0,num):
        output[:,:,i] = local_X[:,:,num-i-1]

    return output


def reshape_new(input):
    d1 = input.shape[0]
    d2 = input.shape[1]
    num = input.shape[2]
    output = np.zeros((d1*d2,num))
    for i in xrange(0,num):
        temp = input[:,:,i]
        output[:,i] = temp.T.reshape((d1*d2))

    return output


def reshape_back(input,d1,d2,num):
    output = np.zeros((d1,d2,num))
    for i in xrange(num):
        temp = input[:,i]
        output[:,:,i] = temp.reshape(d2,d1).T

    return output



def conv(input, mask, kernel_size):
    
    mask = mask[::-1]
    mask = np.fliplr(mask)
    r_in = input.shape[0]
    c_in = input.shape[1]

    step = (kernel_size - 1) / 2
    in_begin_r = step
    in_end_r = r_in - step - 1
    in_begin_c = step
    in_end_c = c_in - step - 1
    
    output = np.zeros((r_in - kernel_size + 1, c_in - kernel_size + 1))

    for i in xrange(in_begin_r,in_end_r+1):
        for j in xrange(in_begin_c,in_end_c+1):
            temp = input[i-step:i+step+1,j-step:j+step+1]
            output[i-step,j-step] = np.sum( np.multiply(temp,mask) )

    return output



def conv_2_nd(input,mask,kernel_size):
    mask = flip_all(mask)
    output_size_1 = input.shape[0] - mask.shape[0] + 1
    output_size_2 = input.shape[1] - mask.shape[1] + 1
    output = np.zeros((output_size_1,output_size_2))

    for i in xrange(0,output_size_1):
        for j in xrange(0,output_size_2):
            output[i,j] = np.sum(np.multiply( input[i:i+kernel_size,j:j+kernel_size,:] , mask))

    return output



def conv_nd(input,mask,kernel_size,mode_name='valid',flag=0):
    num = input.shape[2]
    
    if flag == 1:
        output = np.zeros((input.shape[0] + kernel_size - 1, input.shape[1] + kernel_size - 1, num))
    else:
        output = np.zeros((input.shape[0] - kernel_size + 1, input.shape[1] - kernel_size + 1, num))
    
    for i in xrange(0,num):
        data = input[:,:,i]
        output[:,:,i] = signal.convolve2d(data,mask,mode=mode_name)

    return output



def cnn_ff(data,para,weights):
    
    #2nd layer: first convolutional layer
    outputmaps = para.l_2_outputmaps
    k_s = para.l_2_kernelsize
    mask = weights.net_l_2_k
    bias = weights.net_l_2_b
    
    layer_2_a = np.zeros((data.shape[0]-k_s+1,data.shape[1]-k_s+1,data.shape[2],outputmaps))
    
    for j in xrange(0,outputmaps):
        z = np.zeros((data.shape[0]-k_s+1,data.shape[1]-k_s+1,data.shape[2]))
        z = conv_nd(data,mask[:,:,0,j].reshape((k_s,k_s)),k_s)
        layer_2_a[:,:,:,j] = sigm(z + bias[0,j])

    inputmaps = outputmaps


    #3rd layer: first sub-sampling layer

    scale = para.l_3_scale
    mask = np.ones((scale,scale)) / (scale * scale)
    
    layer_3_a = np.zeros((round(layer_2_a.shape[0]/2.0),round(layer_2_a.shape[1]/2.0),layer_2_a.shape[2],inputmaps))

    for j in xrange(0,inputmaps):
        z = conv_nd(layer_2_a[:,:,:,j],mask,mask.shape[0])
        layer_3_a[:,:,:,j] = z[::2,::2,:]


    #4th layer: second convolutional layer
    outputmaps = para.l_4_outputmaps
    k_s = para.l_4_kernelsize
    mask = weights.net_l_4_k
    bias = weights.net_l_4_b

    layer_4_a = np.zeros((layer_3_a.shape[0]-k_s+1,layer_3_a.shape[1]-k_s+1,layer_3_a.shape[2],outputmaps))

    for j in xrange(0,outputmaps):
        z = np.zeros((layer_3_a.shape[0]-k_s+1,layer_3_a.shape[1]-k_s+1,layer_3_a.shape[2]))

        for i in xrange(0,inputmaps):
            z = z + conv_nd(layer_3_a[:,:,:,i], mask[:,:,i,j],mask.shape[0])

        layer_4_a[:,:,:,j] = sigm(z + bias[0,j])

    inputmaps = outputmaps


    #5th layer: second sub-sampling layer
    scale = para.l_5_scale
    mask = np.ones((scale,scale)) / (scale * scale)

    layer_5_a = np.zeros((round(layer_4_a.shape[0]/2.0),round(layer_4_a.shape[1]/2.0),layer_4_a.shape[2],inputmaps))

    for j in xrange(0,inputmaps):
        z = conv_nd(layer_4_a[:,:,:,j],mask,mask.shape[0])
        layer_5_a[:,:,:,j] = z[::2,::2,:]


    #fully connected layer

    concatenated = np.zeros((layer_5_a.shape[0]*layer_5_a.shape[1]*layer_5_a.shape[3], layer_5_a.shape[2]))
    temp = 0

    for j in xrange(0,inputmaps):
        index_start = temp
        index_end = index_start + layer_5_a.shape[0]*layer_5_a.shape[1]
        temp = index_end
        #concatenated[index_start:index_end,:] = layer_5_a[:,:,:,j].reshape((layer_5_a.shape[0]*layer_5_a.shape[1],layer_5_a.shape[2]))
        concatenated[index_start:index_end,:] = reshape_new(layer_5_a[:,:,:,j])


    net_ffb = weights.net_ff_b
    net_ffW = weights.net_ff_W

    net_output = sigm(np.dot(net_ffW,concatenated) + np.tile(net_ffb,(1,concatenated.shape[1])))

    return (layer_2_a,layer_3_a,layer_4_a,layer_5_a,concatenated,net_output)




def cnn_bp(layer_output,Y,weights,X_train):
    
    net_output = layer_output.net_l_output
    
    net_layer_2_k = weights.net_l_2_k
    net_layer_4_k = weights.net_l_4_k
    
    layer_2_a = layer_output.l_2_a
    layer_3_a = layer_output.l_3_a
    layer_4_a = layer_output.l_4_a
    layer_5_a = layer_output.l_5_a
    concatenated = layer_output.l_concatenated
    
    
    
    net_ffW = weights.net_ff_W

    net_error = net_output - Y
    net_Loss = 0.5 * np.sum( np.power(net_error,2) ) / Y.shape[1]
    
    print "             current loss is ", net_Loss

    net_od = np.multiply(net_error, np.multiply(net_output,1-net_output) )  #output delta
    net_fvd = np.dot(net_ffW.T, net_od)                                     #feature vector delta


    fvnum = layer_5_a.shape[0] * layer_5_a.shape[1]                         #reshape feature vector deltas into output map style
    layer_5_d = np.zeros(layer_5_a.shape)
    for j in xrange(0,layer_5_a.shape[3]):
        #layer_5_d[:,:,:,j] = net_fvd[j*fvnum:(j+1)*fvnum,:].reshape((layer_5_a.shape[0],layer_5_a.shape[1],layer_5_a.shape[2]))
        layer_5_d[:,:,:,j] = reshape_back(net_fvd[j*fvnum:(j+1)*fvnum,:],layer_5_a.shape[0],layer_5_a.shape[1],layer_5_a.shape[2])
    

    #second convolutional layer
    
    layer_5_d_expanded = np.zeros((layer_5_d.shape[0]*2,layer_5_d.shape[1]*2,layer_5_d.shape[2],layer_5_d.shape[3]))  #expand layer_5_d
    for i in xrange(0,layer_5_d_expanded.shape[0]):
        for j in xrange(0,layer_5_d_expanded.shape[1]):
            layer_5_d_expanded[i,j,:,:] = layer_5_d[int((i+0.5)/2),int((j+0.5)/2),:,:]

    layer_5_d_expanded = layer_5_d_expanded / 4

    layer_4_d = np.zeros(layer_5_d_expanded.shape)
    for j in xrange(0,layer_4_a.shape[3]):
        layer_4_d[:,:,:,j] = np.multiply( np.multiply(layer_4_a[:,:,:,j],1-layer_4_a[:,:,:,j]), layer_5_d_expanded[:,:,:,j])



    #second sub-sampling layer
    layer_3_d = np.zeros(layer_3_a.shape)
    for i in xrange(0,layer_3_a.shape[3]):
        z = np.zeros(layer_3_a[:,:,:,0].shape)
        for j in xrange(0,layer_4_a.shape[3]):
            temp = net_layer_4_k[:,:,i,j]
            temp = temp[::-1]
            temp = np.fliplr(temp)
            z = z + conv_nd(layer_4_d[:,:,:,j],temp,temp.shape[0],mode_name='full',flag=1)
        
        layer_3_d[:,:,:,i] = z


    #first convolutional layer
    layer_3_d_expanded = np.zeros((layer_3_d.shape[0]*2,layer_3_d.shape[1]*2,layer_3_d.shape[2],layer_3_d.shape[3]))  #expand layer_3_d
    for i in xrange(0,layer_3_d_expanded.shape[0]):
        for j in xrange(0,layer_3_d_expanded.shape[1]):
            layer_3_d_expanded[i,j,:,:] = layer_3_d[int((i+0.5)/2),int((j+0.5)/2),:,:]

    layer_3_d_expanded = layer_3_d_expanded / 4

    layer_2_d = np.zeros(layer_3_d_expanded.shape)
    for j in xrange(0,layer_2_a.shape[3]):
        layer_2_d[:,:,:,j] = np.multiply( np.multiply(layer_2_a[:,:,:,j],1-layer_2_a[:,:,:,j]), layer_3_d_expanded[:,:,:,j])

    #calculate gradients

    #second layer
    layer_2_dk = np.zeros(net_layer_2_k.shape)
    layer_2_db = np.zeros(net_layer_2_b.shape)
    for j in xrange(0,layer_2_a.shape[3]):
        layer_2_dk[:,:,0,j] = conv_2_nd(flip_all(X_train), layer_2_d[:,:,:,j],layer_2_d.shape[0]) / layer_2_d.shape[2]
        layer_2_db[0,j] = np.sum(layer_2_d[:,:,:,j]) / layer_2_d.shape[2]

    #fourth layer
    layer_4_dk = np.zeros(net_layer_4_k.shape)
    layer_4_db = np.zeros(net_layer_4_b.shape)
    for j in xrange(0,layer_4_a.shape[3]):
        for i in xrange(0,layer_3_a.shape[3]):
            layer_4_dk[:,:,i,j] = conv_2_nd( flip_all(layer_3_a[:,:,:,i]) , layer_4_d[:,:,:,j] ,layer_4_d.shape[0] ) / layer_4_d.shape[2]
        layer_4_db[0,j] = np.sum( layer_4_d[:,:,:,j] ) / layer_4_d.shape[2]

    #fully connected layer
    dffW = np.dot(net_od, concatenated.T) / net_od.shape[1]
    dffb = np.mean(net_od, axis=1)

    return (layer_2_dk,layer_2_db,layer_4_dk,layer_4_db,dffW,dffb,net_Loss)





def cnn_update(weights,dev,layer_output,alpha):
    
    layer_2_dk = dev.l_2_dk
    layer_2_db = dev.l_2_db
    layer_4_dk = dev.l_4_dk
    layer_4_db = dev.l_4_db
    dffW = dev.dff_W
    dffb = dev.dff_b
    
    net_layer_2_k = weights.net_l_2_k
    net_layer_2_b = weights.net_l_2_b
    net_layer_4_k = weights.net_l_4_k
    net_layer_4_b = weights.net_l_4_b
    ffW = weights.net_ff_W
    ffb = weights.net_ff_b
    
    layer_2_a = layer_output.l_2_a
    layer_3_a = layer_output.l_3_a
    layer_4_a = layer_output.l_4_a
    layer_5_a = layer_output.l_5_a
    concatenated = layer_output.l_concatenated

    #first convolutional layer
    for j in xrange(0,layer_2_a.shape[3]):
        net_layer_2_k[:,:,0,j] = net_layer_2_k[:,:,0,j] - alpha * layer_2_dk[:,:,0,j]
        net_layer_2_b[0,j] = net_layer_2_b[0,j] - alpha * layer_2_db[0,j]

    #second convolutional layer
    for j in xrange(0,layer_4_a.shape[3]):
        for i in xrange(0,layer_3_a.shape[3]):
            net_layer_4_k[:,:,i,j] = net_layer_4_k[:,:,i,j] - alpha * layer_4_dk[:,:,i,j]
        net_layer_4_b[0,j] = net_layer_4_b[0,j] - layer_4_db[0,j]

    #fully connected layer
    ffW = ffW - alpha * dffW
    ffb[:,0] = ffb[:,0] - alpha * dffb

    return (net_layer_2_k,net_layer_2_b,net_layer_4_k,net_layer_4_b,ffW,ffb)




def cnn_test(X,Y,para,weights):
    layer_2_a,layer_3_a,layer_4_a,layer_5_a,concatenated,net_output = cnn_ff(X,para,weights)
    
    predicted = net_output.argmax(axis=0)
    label = Y.argmax(axis=0)
    accuracy = (np.sum(predicted == label) + 0.) / label.shape[0]
    
    return accuracy




#------------------------------------------------------------------------------------------------
#loading training and testing data
X_train, y_train, X_val, y_val, X_test, y_test = load_dataset()

# num * dimension
#X_train = X_train.reshape(50000,28*28)
#X_test = X_test.reshape(10000,28*28)

X_train = X_train.transpose((2,3,0,1)).reshape((28,28,50000))
X_test = X_test.transpose((2,3,0,1)).reshape((28,28,10000))



Y_train = np.zeros((10,y_train.shape[0]))
for i in xrange(y_train.shape[0]):
    Y_train[y_train[i],i] = 1

Y_test = np.zeros((10,y_test.shape[0]))
for i in xrange(y_test.shape[0]):
    Y_test[y_test[i],i] = 1


#------------------------------------------------------------------------------------------------
#initialize the network
#this is a input-6c-2s-12c-2s-output Convolutional neural network

#specify parameters
layer_2_outputmaps = 6
layer_2_kernelsize = 5
layer_3_scale = 2
layer_4_outputmaps = 12
layer_4_kernelsize = 5
layer_5_scale = 2

alpha = 1

para = net_para(l_2_outputmaps=6,l_2_kernelsize=5,l_3_scale=2,l_4_outputmaps=12,l_4_kernelsize=5,l_5_scale=2)


print "initialization start"

start = time.time()

#second layer: first convolutional layer
inputmaps = 1
k_s = layer_2_kernelsize
mapsize = X_train.shape[0]
mapsize = mapsize - k_s + 1
fan_out = layer_2_outputmaps * k_s * k_s

net_layer_2_k = np.zeros((k_s,k_s,1,layer_2_outputmaps))
net_layer_2_b = np.zeros((1,layer_2_outputmaps))

for j in xrange(0,layer_2_outputmaps):
    fan_in = inputmaps * k_s * k_s
    net_layer_2_k[:,:,0,j] = ( np.random.uniform(0,1,(k_s, k_s)) - 0.5 ) * 2. * np.sqrt(6. / (fan_in + fan_out))


#third layer: first sub-sampling layer
inputmaps = layer_2_outputmaps
mapsize = mapsize / layer_3_scale
net_layer_3_b = np.zeros((1,inputmaps))


#fourth layer: second convolutional layer
k_s = layer_4_kernelsize

mapsize = mapsize - k_s + 1
fan_out = layer_4_outputmaps * k_s * k_s

net_layer_4_k = np.zeros((k_s,k_s,inputmaps,layer_4_outputmaps))
net_layer_4_b = np.zeros((1,layer_4_outputmaps))

for j in xrange(0,layer_4_outputmaps):
    fan_in = inputmaps * k_s * k_s
    for i in xrange(0,inputmaps):
        net_layer_4_k[:,:,i,j] = ( np.random.uniform(0,1,(k_s, k_s)) - 0.5 ) * 2. * np.sqrt(6. / (fan_in + fan_out))


#fifth layer:  second sub-sampling layer
inputmaps = layer_4_outputmaps
mapsize = mapsize / layer_5_scale
net_layer_5_b = np.zeros((1,inputmaps))


#output layer: fully connected layer
fvnum = mapsize * mapsize * inputmaps
onum = 10

net_ffb = np.zeros((onum,1))
net_ffW = ( np.random.uniform(0,1,(onum, fvnum)) - 0.5 ) * 2. * np.sqrt(6. / (onum + fvnum))



weights = net_weights(net_l_2_k=net_layer_2_k,net_l_2_b=net_layer_2_b,net_l_3_b=net_layer_3_b,net_l_4_k=net_layer_4_k,net_l_4_b=net_layer_4_b,net_l_5_b=net_layer_5_b,net_ff_b=net_ffb,net_ff_W=net_ffW)


print "     initialization done"

times = time.time() - start
print "  initialization time (s): ", times


#------------------------------------------------------------------------------------------------
#train the network
print "                 "
print "training start"

num_epochs = 50
batch_size = 100
loss = np.zeros((1,500000))
counter = -1

test_acc = np.zeros((1,500))

for ite in xrange(num_epochs):

    print "   at iteration ", ite+1, " of ", num_epochs
    
    
    index_random = np.random.permutation(range(X_train.shape[2]))
    num_batch = X_train.shape[2] / batch_size
    
    for i in xrange(num_batch):
        
        print "         at batch ", i+1, " of ", num_batch, "   at iteration ", ite+1, " of ", num_epochs
        
        current_batch_index = index_random[i*batch_size:(i+1)*batch_size]
        current_X_train = X_train[:,:,current_batch_index]
        current_Y_train = Y_train[:,current_batch_index]

        start = time.time()
        layer_2_a,layer_3_a,layer_4_a,layer_5_a,concatenated,net_output = cnn_ff(current_X_train,para,weights)

        layer_output = net_layer_output(l_2_a=layer_2_a,l_3_a=layer_3_a,l_4_a=layer_4_a,l_5_a=layer_5_a,l_concatenated=concatenated,net_l_output=net_output)
        times = time.time() - start
        print "             forward time (s): ", times

        start = time.time()
        layer_2_dk,layer_2_db,layer_4_dk,layer_4_db,dffW,dffb,net_loss = cnn_bp(layer_output,current_Y_train,weights,current_X_train)
        
        counter = counter + 1
        loss[0,counter] = net_loss
        

        layer_dev = net_dev(l_2_dk=layer_2_dk,l_2_db=layer_2_db,l_4_dk=layer_4_dk,l_4_db=layer_4_db,dff_W=dffW,dff_b=dffb)
        times = time.time() - start
        print "             backpropagate time (s): ", times

        start = time.time()
        net_layer_2_k,net_layer_2_b,net_layer_4_k,net_layer_4_b,ffW,ffb = cnn_update(weights,layer_dev,layer_output,alpha)

        weights.net_l_2_k = net_layer_2_k
        weights.net_l_2_b = net_layer_2_b
        weights.net_l_4_k = net_layer_4_k
        weights.net_l_4_b = net_layer_4_b
        weights.net_ff_W = ffW
        weights.net_ff_b = ffb
        times = time.time() - start
        print "             update time (s): ", times

    #acc = cnn_test(X_train,Y_train,para,weights)
    #print "   training accuracy is ", acc
    acc = cnn_test(X_test,Y_test,para,weights)
    print "    testing accuracy is ", acc

    test_acc[0,ite] = acc
    np.savetxt('loss.txt',loss)
    np.savetxt('acc.txt',test_acc)




#test the network
#acc = cnn_test(X_test,Y_test,para,weights)
#print "testing accuracy is ", acc

np.savetxt('loss.txt',loss)
np.savetxt('acc.txt',test_acc)








