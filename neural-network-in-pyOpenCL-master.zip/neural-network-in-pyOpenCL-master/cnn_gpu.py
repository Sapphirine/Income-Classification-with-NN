#!/usr/bin/env python

import numpy as np
from urllib import urlretrieve
import cPickle as pickle
import os
import gzip
import time
from scipy import signal

import pyopencl as cl
import pyopencl.array
import csv



## Select the desired OpenCL platform:
NAME = 'NVIDIA CUDA'
platforms = cl.get_platforms()
devs = None
for platform in platforms:
    if platform.name == NAME:
        devs = platform.get_devices()

# Set up a command queue:
ctx = cl.Context(devs[0:1])
queue = cl.CommandQueue(ctx)


#---------------------------------------------------------------------------------------
# Define the conv_nd OpenCL kernel:
func_conv_multi_mask = cl.Program(ctx, """
    __kernel void func(__global const float *img, __global const float *fil, __global float *conved, const unsigned int k_s, const unsigned int img_h,const unsigned int img_w,const unsigned int img_d, const unsigned int num_map) {
    
    unsigned int r = get_global_id(0);
    unsigned int c = get_global_id(1);
    unsigned int cur_d = get_global_id(2);
    
    int s = k_s;
    int h = img_h;
    int w = img_w;
    int d = img_d;
    int m = num_map;
    
    
    //rth row, cth column, num th image
    
    
    for (int cur_map = 0; cur_map < m; cur_map++)
    {
    float sum_cur = 0.0f;
    for (int i = 0; i < s; i++)
    {
    for (int j = 0; j < s; j++)
    {
    float value = img[ (r+i)*h*d + (c+j)*d + (cur_d)];
    float mask_value = fil[(s - i - 1)*s*m + (s - j - 1)*m + cur_map];
    sum_cur += value * mask_value;
    }
    }
    
    
    conved[(r)*(h-s+1)*d*m + (c)*d*m + cur_d*m + cur_map] = sum_cur;
    }
    
    
    }
    """).build().func

func_conv_multi_mask.set_scalar_arg_dtypes([None, None, None, np.uint32, np.uint32, np.uint32, np.uint32,np.uint32])


#---------------------------------------------------------------------------------------
# Define the conv_2_nd OpenCL kernel:
func_conv_2 = cl.Program(ctx, """
    __kernel void func(__global float *img, __global float *fil, __global float *conved, __global float* k_s, __global float* img_h, __global float* img_w, __global float* img_d) {
    
    unsigned int r = get_global_id(0);
    unsigned int c = get_global_id(1);
    
    int s = k_s[0];
    int h = img_h[0];
    int w = img_w[0];
    int d = img_d[0];
    
    float sum_cur = 0.0f;
    
    for (int i = 0; i < s; i++)
    {
    for (int j = 0; j < s; j++)
    {
    for (int k = 0; k < d; k++)
    {
    float value1 = img[ (r+i)*h*d + (c+j)*d + (k)];
    float value2 = fil[(i)*s*d + (j)*d + (k)];
    sum_cur += value1 * value2;
    }
    }
    }
    
    conved[r*(w - s + 1) + c] = sum_cur;
    
    
    }
    """).build().func

func_conv_2.set_scalar_arg_dtypes([None, None, None, None, None, None, None])


#------------------------------------------------------------------------------------
# Define the OpenCL kernel:
func_conv_multi_img_mask = cl.Program(ctx, """
    __kernel void func(__global const float *img, __global const float *fil, __global float *conved, const unsigned int k_s, const unsigned int img_h,const unsigned int img_d, const unsigned int num_map, const unsigned int num_out_map) {
    
    unsigned int r = get_global_id(0);
    unsigned int c = get_global_id(1);
    unsigned int cur_d = get_global_id(2);
    
    int s = k_s;
    int h = img_h;
    int d = img_d;
    int m = num_map;
    int n = num_out_map;
    
    
    //rth row, cth column, num th image
    
    
    for (int cur_map = 0; cur_map < m; cur_map++)
    {
    for (int cur_out = 0; cur_out < n; cur_out++)
    {
    float sum_cur = 0.0f;
    for (int i = 0; i < s; i++)
    {
    for (int j = 0; j < s; j++)
    {
    float value = img[ (r+i)*h*d*m + (c+j)*d*m + (cur_d)*m + cur_map];
    float mask_value = fil[(s - i - 1)*s*m*n + (s - j - 1)*m*n + (cur_map)*n + cur_out];
    sum_cur += value * mask_value;
    }
    }
    
    
    conved[(r)*(h-s+1)*d*m*n + (c)*d*m*n + cur_d*m*n + cur_map*n + cur_out] = sum_cur;
    }
    }
    
    
    }
    """).build().func

func_conv_multi_img_mask.set_scalar_arg_dtypes([None, None, None, np.uint32, np.uint32, np.uint32, np.uint32,np.uint32])

#------------------------------------------------------------------------------------
# Define the OpenCL kernel:
func_conv_multi_img = cl.Program(ctx, """
    __kernel void func(__global const float *img, __global const float *fil, __global float *conved, const unsigned int k_s, const unsigned int img_h,const unsigned int img_w,const unsigned int img_d, const unsigned int num_map) {
    
    unsigned int r = get_global_id(0);
    unsigned int c = get_global_id(1);
    unsigned int cur_d = get_global_id(2);
    
    int s = k_s;
    int h = img_h;
    int w = img_w;
    int d = img_d;
    int m = num_map;
    
    
    //rth row, cth column, num th image
    
    
    for (int cur_map = 0; cur_map < m; cur_map++)
    {
    float sum_cur = 0.0f;
    for (int i = 0; i < s; i++)
    {
    for (int j = 0; j < s; j++)
    {
    float value = img[ (r+i)*h*d*m + (c+j)*d*m + (cur_d)*m + cur_map];
    float mask_value = fil[(s - i - 1)*s + (s - j - 1)];
    sum_cur += value * mask_value;
    }
    }
    
    
    conved[(r)*(h-s+1)*d*m + (c)*d*m + cur_d*m + cur_map] = sum_cur;
    }
    
    
    }
    """).build().func

func_conv_multi_img.set_scalar_arg_dtypes([None, None, None, np.uint32, np.uint32, np.uint32, np.uint32,np.uint32])


#------------------------------------------------------------------------------------
# Define the OpenCL kernel:
func_conv_multi_img_mask_bp = cl.Program(ctx, """
    __kernel void func(__global const float *img, __global const float *fil, __global float *conved, const unsigned int k_s, const unsigned int img_h,const unsigned int img_d, const unsigned int num_map, const unsigned int num_out_map) {
    
    unsigned int r = get_global_id(0);
    unsigned int c = get_global_id(1);
    unsigned int cur_d = get_global_id(2);
    
    int s = k_s;
    int h = img_h;
    int d = img_d;
    int m = num_map;
    int n = num_out_map;
    
    
    //rth row, cth column, num th image
    
    
    for (int cur_map = 0; cur_map < m; cur_map++)
    {
    for (int cur_out = 0; cur_out < n; cur_out++)
    {
    float sum_cur = 0.0f;
    for (int i = 0; i < s; i++)
    {
    for (int j = 0; j < s; j++)
    {
    float value = img[(h-r-i-1)*h*d*m + (h-c-j-1)*d*m + (d-cur_d-1)*m + (cur_map)];
    
    //float value = img[(h-r-i-1)*h*d*m*n + (h-c-j-1)*d*m*n + (d-cur_d-1)*m*n + (cur_map)*m + (cur_out)*n];
    float mask_value = fil[(s-i-1)*s*d*n + (s-j-1)*d*n + (d-cur_d-1)*n + (cur_out)];
    
    sum_cur += value * mask_value;
    
    
    //float value = img[ (r+i)*h*d*m + (c+j)*d*m + (cur_d)*m + cur_map];
    //float mask_value = fil[(s - i - 1)*s*m*n + (s - j - 1)*m*n + (cur_map)*n + cur_out];
    //sum_cur += value * mask_value;
    }
    }
    
    conved[(r)*(h-s+1)*d*m*n + (c)*d*m*n + (cur_d)*m*n + (cur_map)*n + (cur_out)] = sum_cur;
    
    
    //conved[(r)*(h-s+1)*d*m*n + (c)*d*m*n + cur_d*m*n + cur_map*n + cur_out] = sum_cur;
    }
    }
    
    
    }
    """).build().func

func_conv_multi_img_mask_bp.set_scalar_arg_dtypes([None, None, None, np.uint32, np.uint32, np.uint32, np.uint32,np.uint32])

#------------------------------------------------------------------------------------------------


#structure designed to store net parameters
class net_para(object):
    def __init__(self,l_2_outputmaps,l_2_kernelsize,l_3_scale,l_4_outputmaps,l_4_kernelsize,l_5_scale):
        self.l_2_outputmaps = l_2_outputmaps
        self.l_2_kernelsize = l_2_kernelsize
        self.l_3_scale = l_3_scale
        self.l_4_outputmaps = l_4_outputmaps
        self.l_4_kernelsize = l_4_kernelsize
        self.l_5_scale = l_5_scale

#structure designed to store net weights
class net_weights(object):
    def __init__(self,net_l_2_k,net_l_2_b,net_l_3_b,net_l_4_k,net_l_4_b,net_l_5_b,net_ff_b,net_ff_W):
        self.net_l_2_k = net_l_2_k
        self.net_l_2_b = net_l_2_b
        self.net_l_3_b = net_l_3_b
        self.net_l_4_k = net_l_4_k
        self.net_l_4_b = net_l_4_b
        self.net_l_5_b = net_l_5_b
        self.net_ff_b = net_ff_b
        self.net_ff_W = net_ff_W

#structure designed to store net outputs
class net_layer_output(object):
    def __init__(self,l_2_a,l_3_a,l_4_a,l_5_a,l_concatenated,net_l_output):
        self.l_2_a = l_2_a
        self.l_3_a = l_3_a
        self.l_4_a = l_4_a
        self.l_5_a = l_5_a
        self.l_concatenated = l_concatenated
        self.net_l_output = net_l_output

#structure designed to store net derivatives
class net_dev(object):
    def __init__(self,l_2_dk,l_2_db,l_4_dk,l_4_db,dff_W,dff_b):
        self.l_2_dk = l_2_dk
        self.l_2_db = l_2_db
        self.l_4_dk = l_4_dk
        self.l_4_db = l_4_db
        self.dff_W = dff_W
        self.dff_b = dff_b



#------------------------------------------------------------------------------------------------

#function used to load dataset
def load_dataset():
    url = 'http://deeplearning.net/data/mnist/mnist.pkl.gz'
    filename = 'mnist.pkl.gz'
    if not os.path.exists(filename):
        print("Downloading MNIST dataset...")
        urlretrieve(url, filename)
    
    with gzip.open(filename, 'rb') as f:
        data = pickle.load(f)
    
    X_train, y_train = data[0]
    X_val, y_val = data[1]
    X_test, y_test = data[2]

    X_train = X_train.reshape((-1, 1, 28, 28))
    X_val = X_val.reshape((-1, 1, 28, 28))
    X_test = X_test.reshape((-1, 1, 28, 28))
    
    y_train = y_train.astype(np.uint8)
    y_val = y_val.astype(np.uint8)
    y_test = y_test.astype(np.uint8)
    
    return (X_train, y_train, X_val, y_val, X_test, y_test)


#sigmoid function
def sigm(input):
    return 1/(1+np.exp(-input))


def flip_all(X_input):
    num = X_input.shape[2]
    local_X = np.zeros(X_input.shape)
    for i in xrange(0,num):
        temp = X_input[:,:,i]
        temp = temp[::-1]
        temp = np.fliplr(temp)
        local_X[:,:,i] = temp

    output = np.zeros((X_input.shape))
    for i in xrange(0,num):
        output[:,:,i] = local_X[:,:,num-i-1]

    return output


def reshape_new(input):
    d1 = input.shape[0]
    d2 = input.shape[1]
    num = input.shape[2]
    output = np.zeros((d1*d2,num))
    for i in xrange(0,num):
        temp = input[:,:,i]
        output[:,i] = temp.T.reshape((d1*d2))

    return output


def reshape_back(input,d1,d2,num):
    output = np.zeros((d1,d2,num))
    for i in xrange(num):
        temp = input[:,i]
        output[:,:,i] = temp.reshape(d2,d1).T

    return output




def conv_2_nd(input,mask,kernel_size):
    mask = flip_all(mask)
    output_size_1 = input.shape[0] - mask.shape[0] + 1
    output_size_2 = input.shape[1] - mask.shape[1] + 1
    output = np.zeros((output_size_1,output_size_2))

    for i in xrange(0,output_size_1):
        for j in xrange(0,output_size_2):
            output[i,j] = np.sum(np.multiply( input[i:i+kernel_size,j:j+kernel_size,:] , mask))

    return output


def conv_2_nd_gpu(input,mask,kernel_size):
    mask = flip_all(mask)
    output_size_1 = input.shape[0] - mask.shape[0] + 1
    output_size_2 = input.shape[1] - mask.shape[1] + 1
    output = np.zeros((output_size_1,output_size_2))
    
    img = np.zeros(input.shape).astype(np.float32)
    filter = np.zeros(mask.shape).astype(np.float32)
    
    img[:,:,:] = input[:,:,:]
    filter[:,:,:] = mask[:,:,:]
    
    img_h = np.random.randint(0,1,1).astype(np.float32)
    img_w = np.random.randint(0,1,1).astype(np.float32)
    img_d = np.random.randint(0,1,1).astype(np.float32)
    k_s = np.random.randint(0,1,1).astype(np.float32)
    img_h[0] = input.shape[0]
    img_w[0] = input.shape[1]
    img_d[0] = input.shape[2]
    k_s[0] = kernel_size
    
    img_gpu = cl.array.to_device(queue, img)
    filter_gpu = cl.array.to_device(queue, filter)
    img_h_gpu = cl.array.to_device(queue, img_h)
    img_w_gpu = cl.array.to_device(queue, img_w)
    img_d_gpu = cl.array.to_device(queue, img_d)
    k_s_gpu = cl.array.to_device(queue, k_s)
    
    output_gpu = cl.array.empty(queue, (output.shape[0], output.shape[1]), img.dtype)
    
    func_conv_2(queue,(output.shape[0],output.shape[1]),None,img_gpu.data,filter_gpu.data,output_gpu.data,k_s_gpu.data,img_h_gpu.data,img_w_gpu.data,img_d_gpu.data)
    
    output = output_gpu.get()
    
    return output



def conv_nd(input,mask,kernel_size,mode_name='valid',flag=0):
    num = input.shape[2]
    
    if flag == 1:
        output = np.zeros((input.shape[0] + kernel_size - 1, input.shape[1] + kernel_size - 1, num))
    else:
        output = np.zeros((input.shape[0] - kernel_size + 1, input.shape[1] - kernel_size + 1, num))
    
    for i in xrange(0,num):
        data = input[:,:,i]
        output[:,:,i] = signal.convolve2d(data,mask,mode=mode_name)

    return output


def conv_nd_gpu(input,mask,kernel_size,flag=0):
    
    
    num = input.shape[2]
    M = input.shape[0]
    num_map = input.shape[3]
    
    if flag == 1:
        temp = np.zeros((M+(kernel_size-1)*2, M+(kernel_size-1)*2, num, num_map)).astype(np.float32)
        temp[(kernel_size-1):(M+kernel_size-1),(kernel_size-1):(M+kernel_size-1),:,:] = input
        input = temp
        M = input.shape[0]
    
    output_size_1 = input.shape[0] - kernel_size + 1
    output_size_2 = input.shape[1] - kernel_size + 1
    
    img = np.zeros(input.shape).astype(np.float32)
    img[:,:,:,:] = input[:,:,:,:]
    fil = np.zeros(mask.shape).astype(np.float32)
    fil[:,:] = mask[:,:]
    
    
    img_gpu = cl.array.to_device(queue, img)
    filter_gpu = cl.array.to_device(queue, fil)
    
    output_gpu = cl.array.empty(queue, (output_size_1, output_size_2,num, num_map), img.dtype)
    
    
    func_conv(queue,(output_size_1,output_size_2,num),None,img_gpu.data,filter_gpu.data,output_gpu.data,kernel_size,input.shape[0],input.shape[1],input.shape[2],input.shape[3])
    
    
    times_local = []
    start_local = time.time()
    
    output_conv = output_gpu.get()
    
    
    
    return output_conv

def conv_gpu_multi_mask(input,mask,kernel_size,flag=0):
    
    
    num = input.shape[2]
    M = input.shape[0]
    num_map = mask.shape[2]
    
    img = np.zeros(input.shape).astype(np.float32)
    img[:,:,:] = input[:,:,:]
    fil = np.zeros(mask.shape).astype(np.float32)
    fil[:,:,:] = mask[:,:,:]
    
    if flag == 1:
        temp = np.zeros((M+(kernel_size-1)*2, M+(kernel_size-1)*2, num)).astype(np.float32)
        temp[(kernel_size-1):(M+kernel_size-1),(kernel_size-1):(M+kernel_size-1),:] = input
        input = temp
        M = input.shape[0]
    
    output_size_1 = input.shape[0] - kernel_size + 1
    output_size_2 = input.shape[1] - kernel_size + 1
    
    
    img_gpu = cl.array.to_device(queue, img)
    filter_gpu = cl.array.to_device(queue, fil)
    
    output_gpu = cl.array.empty(queue, (output_size_1, output_size_2,num, num_map), img.dtype)
    
    
    func_conv_multi_mask(queue,(output_size_1,output_size_2,num),None,img_gpu.data,filter_gpu.data,output_gpu.data,kernel_size,input.shape[0],input.shape[1],input.shape[2],mask.shape[2])
    
    output_conv = output_gpu.get()
    
    return output_conv


def conv_gpu_multi_img(input,mask,kernel_size,flag=0):
    
    
    num = input.shape[2]
    M = input.shape[0]
    num_map = input.shape[3]
    
    img = np.zeros(input.shape).astype(np.float32)
    img[:,:,:,:] = input[:,:,:,:]
    fil = np.zeros(mask.shape).astype(np.float32)
    fil[:,:] = mask[:,:]
    
    if flag == 1:
        temp = np.zeros((M+(kernel_size-1)*2, M+(kernel_size-1)*2, num)).astype(np.float32)
        temp[(kernel_size-1):(M+kernel_size-1),(kernel_size-1):(M+kernel_size-1),:] = input
        input = temp
        M = input.shape[0]
    
    output_size_1 = input.shape[0] - kernel_size + 1
    output_size_2 = input.shape[1] - kernel_size + 1
    
    
    img_gpu = cl.array.to_device(queue, img)
    filter_gpu = cl.array.to_device(queue, fil)
    
    output_gpu = cl.array.empty(queue, (output_size_1, output_size_2,num, num_map), img.dtype)
    
    func_conv_multi_img(queue,(output_size_1,output_size_2,num),None,img_gpu.data,filter_gpu.data,output_gpu.data,kernel_size,M,M,num,num_map)
    
    output_conv = output_gpu.get()
    
    return output_conv


def conv_gpu_multi_img_mask(input,mask,kernel_size,flag=0):
    
    
    num = input.shape[2]
    M = input.shape[0]
    num_map = input.shape[3]
    num_out = mask.shape[3]
    
    if flag == 1:
        temp = np.zeros((M+(kernel_size-1)*2, M+(kernel_size-1)*2, num, num_map)).astype(np.float32)
        temp[(kernel_size-1):(M+kernel_size-1),(kernel_size-1):(M+kernel_size-1),:,:] = input
        input = temp
        M = input.shape[0]
    
    img = np.zeros(input.shape).astype(np.float32)
    img[:,:,:,:] = input[:,:,:,:]
    fil = np.zeros(mask.shape).astype(np.float32)
    fil[:,:,:,:] = mask[:,:,:,:]

    output_size_1 = input.shape[0] - kernel_size + 1
    output_size_2 = input.shape[1] - kernel_size + 1
    
    img_gpu = cl.array.to_device(queue, img)
    filter_gpu = cl.array.to_device(queue, fil)
    
    output_gpu = cl.array.empty(queue, (output_size_1, output_size_2,num, num_map, num_out), img.dtype)
    
    func_conv_multi_img_mask(queue,(output_size_1,output_size_2,num),None,img_gpu.data,filter_gpu.data,output_gpu.data,kernel_size,M,num,num_map, num_out)
    
    output_conv = output_gpu.get()
    
    return output_conv


def conv_gpu_multi_img_mask_bp(input,mask,flag=0):
    
    if flag == 1:
        num = input.shape[2]
        M = input.shape[0]
        kernel_size = mask.shape[0]
        num_map = input.shape[3]
        num_out = mask.shape[3]
        img = np.zeros(input.shape).astype(np.float32)
        img[:,:,:,:] = input[:,:,:,:]
        fil = np.zeros(mask.shape).astype(np.float32)
        fil[:,:,:,:] = mask[:,:,:,:]
    else:
        num = input.shape[2]
        M = input.shape[0]
        kernel_size = mask.shape[0]
        num_map = 1
        num_out = mask.shape[3]
        img = np.zeros(input.shape).astype(np.float32)
        img[:,:,:] = input[:,:,:]
        fil = np.zeros(mask.shape).astype(np.float32)
        fil[:,:,:,:] = mask[:,:,:,:]
    
    output_size_1 = input.shape[0] - kernel_size + 1
    output_size_2 = input.shape[1] - kernel_size + 1
    
    
    img_gpu = cl.array.to_device(queue, img)
    filter_gpu = cl.array.to_device(queue, fil)
    
    output_gpu = cl.array.empty(queue, (output_size_1, output_size_2, num, num_map, num_out), img.dtype)
    
    func_conv_multi_img_mask_bp(queue,(output_size_1,output_size_2,num),None,img_gpu.data,filter_gpu.data,output_gpu.data,kernel_size,M,num,num_map, num_out)
    
    output_conv = output_gpu.get()
    
    return output_conv



def cnn_ff(data,para,weights):
    
    #2nd layer: first convolutional layer
    outputmaps = para.l_2_outputmaps
    k_s = para.l_2_kernelsize
    mask = weights.net_l_2_k
    bias = weights.net_l_2_b
    
    layer_2_a = conv_gpu_multi_mask(data,mask[:,:,0,:],5)
    
    for j in xrange(0,outputmaps):
        layer_2_a[:,:,:,j] = layer_2_a[:,:,:,j] + bias[0,j]
    
    layer_2_a = sigm(layer_2_a)

    inputmaps = outputmaps


    #3rd layer: first sub-sampling layer
    scale = para.l_3_scale
    mask = np.ones((scale,scale)).astype(np.float32) / (scale * scale)

    layer_3_a = np.zeros((round(layer_2_a.shape[0]/2.0),round(layer_2_a.shape[1]/2.0),layer_2_a.shape[2],inputmaps)).astype(np.float32)

    layer_3_a_temp = conv_gpu_multi_img(layer_2_a,mask,mask.shape[0])

    for j in xrange(0,inputmaps):
        layer_3_a[:,:,:,j] = layer_3_a_temp[::2,::2,:,j]


    #4th layer: second convolutional layer
    outputmaps = para.l_4_outputmaps
    k_s = para.l_4_kernelsize
    mask = weights.net_l_4_k
    bias = weights.net_l_4_b

    layer_4_a = np.zeros((layer_3_a.shape[0]-k_s+1,layer_3_a.shape[1]-k_s+1,layer_3_a.shape[2],outputmaps)).astype(np.float32)


    layer_4_a_temp = conv_gpu_multi_img_mask(layer_3_a,mask,mask.shape[0])

    layer_4_a = np.sum(layer_4_a_temp,axis=3)


    for j in xrange(0,outputmaps):
        layer_4_a[:,:,:,j] = sigm(layer_4_a[:,:,:,j] + bias[0,j])

    inputmaps = outputmaps

    #5th layer: second sub-sampling layer
    scale = para.l_5_scale
    mask = np.ones((scale,scale)).astype(np.float32) / (scale * scale)

    layer_5_a = np.zeros((round(layer_4_a.shape[0]/2.0),round(layer_4_a.shape[1]/2.0),layer_4_a.shape[2],inputmaps)).astype(np.float32)

    layer_5_a_temp = conv_gpu_multi_img(layer_4_a,mask,mask.shape[0])

    for j in xrange(0,inputmaps):
        layer_5_a[:,:,:,j] = layer_5_a_temp[::2,::2,:,j]


    #fully connected layer
    concatenated = np.zeros((layer_5_a.shape[0]*layer_5_a.shape[1]*layer_5_a.shape[3], layer_5_a.shape[2])).astype(np.float32)
    temp = 0

    for j in xrange(0,inputmaps):
        index_start = temp
        index_end = index_start + layer_5_a.shape[0]*layer_5_a.shape[1]
        temp = index_end
        concatenated[index_start:index_end,:] = reshape_new(layer_5_a[:,:,:,j])


    net_ffb = weights.net_ff_b
    net_ffW = weights.net_ff_W

    net_output = sigm(np.dot(net_ffW,concatenated) + np.tile(net_ffb,(1,concatenated.shape[1])))
    

    return (layer_2_a,layer_3_a,layer_4_a,layer_5_a,concatenated,net_output)




def cnn_bp(layer_output,Y,weights,X_train):
    
    net_output = layer_output.net_l_output
    
    net_layer_2_k = weights.net_l_2_k
    net_layer_4_k = weights.net_l_4_k
    
    layer_2_a = layer_output.l_2_a
    layer_3_a = layer_output.l_3_a
    layer_4_a = layer_output.l_4_a
    layer_5_a = layer_output.l_5_a
    concatenated = layer_output.l_concatenated
    
    
    
    net_ffW = weights.net_ff_W
    net_error = net_output - Y
    net_Loss = 0.5 * np.sum( np.power(net_error,2) ) / Y.shape[1]
    
    print "             current loss is ", net_Loss


    net_od = np.multiply(net_error, np.multiply(net_output,1-net_output) )  #output delta
    net_fvd = np.dot(net_ffW.T, net_od)                                     #feature vector delta

    fvnum = layer_5_a.shape[0] * layer_5_a.shape[1]                         #reshape feature vector deltas into output map style
    layer_5_d = np.zeros(layer_5_a.shape).astype(np.float32)
    for j in xrange(0,layer_5_a.shape[3]):
        layer_5_d[:,:,:,j] = reshape_back(net_fvd[j*fvnum:(j+1)*fvnum,:],layer_5_a.shape[0],layer_5_a.shape[1],layer_5_a.shape[2])
    

    #second convolutional layer
    layer_5_d_expanded = np.zeros((layer_5_d.shape[0]*2,layer_5_d.shape[1]*2,layer_5_d.shape[2],layer_5_d.shape[3])).astype(np.float32)  #expand layer_5_d
    for i in xrange(0,layer_5_d_expanded.shape[0]):
        for j in xrange(0,layer_5_d_expanded.shape[1]):
            layer_5_d_expanded[i,j,:,:] = layer_5_d[int((i+0.5)/2),int((j+0.5)/2),:,:]

    layer_5_d_expanded = layer_5_d_expanded / 4

    layer_4_d = np.zeros(layer_5_d_expanded.shape).astype(np.float32)
    for j in xrange(0,layer_4_a.shape[3]):
        layer_4_d[:,:,:,j] = np.multiply( np.multiply(layer_4_a[:,:,:,j],1-layer_4_a[:,:,:,j]), layer_5_d_expanded[:,:,:,j])

    #second sub-sampling layer
    net_layer_4_k_temp = np.zeros(net_layer_4_k.shape).astype(np.float32)

    for i in xrange(0,layer_3_a.shape[3]):
        for j in xrange(0,layer_4_a.shape[3]):
            temp = net_layer_4_k[:,:,i,j]
            temp = temp[::-1]
            temp = np.fliplr(temp)
            net_layer_4_k_temp[:,:,i,j] = temp

    net_layer_4_k_temp = net_layer_4_k_temp.transpose((0,1,3,2))
    layer_3_d_temp = conv_gpu_multi_img_mask(layer_4_d,net_layer_4_k_temp,net_layer_4_k_temp.shape[0],flag=1)
    layer_3_d = np.sum(layer_3_d_temp,axis=3)

    #first convolutional layer
    layer_3_d_expanded = np.zeros((layer_3_d.shape[0]*2,layer_3_d.shape[1]*2,layer_3_d.shape[2],layer_3_d.shape[3])).astype(np.float32)  #expand layer_3_d
    for i in xrange(0,layer_3_d_expanded.shape[0]):
        for j in xrange(0,layer_3_d_expanded.shape[1]):
            layer_3_d_expanded[i,j,:,:] = layer_3_d[int((i+0.5)/2),int((j+0.5)/2),:,:]

    layer_3_d_expanded = layer_3_d_expanded / 4

    layer_2_d = np.zeros(layer_3_d_expanded.shape).astype(np.float32)
    for j in xrange(0,layer_2_a.shape[3]):
        layer_2_d[:,:,:,j] = np.multiply( np.multiply(layer_2_a[:,:,:,j],1-layer_2_a[:,:,:,j]), layer_3_d_expanded[:,:,:,j])

    #calculate gradients

    #second layer
    layer_2_db = np.zeros(net_layer_2_b.shape).astype(np.float32)

    for j in xrange(0,layer_2_a.shape[3]):
        layer_2_db[0,j] = np.sum(layer_2_d[:,:,:,j]) / (layer_2_d.shape[2]+0.0)


    layer_2_dk = conv_gpu_multi_img_mask_bp(X_train, layer_2_d, flag=0)
    layer_2_dk = np.sum(layer_2_dk,axis=2) / (layer_2_d.shape[2]+0.0)

    #fourth layer
    layer_4_db = np.zeros(net_layer_4_b.shape).astype(np.float32)



    for j in xrange(0,layer_4_a.shape[3]):
        layer_4_db[0,j] = np.sum( layer_4_d[:,:,:,j] ) / (layer_4_d.shape[2]+0.0)


    layer_4_dk = conv_gpu_multi_img_mask_bp(layer_3_a,layer_4_d,flag=1)
    layer_4_dk = np.sum(layer_4_dk,axis=2) / (layer_4_d.shape[2]+0.0)

    #fully connected layer
    dffW = np.dot(net_od, concatenated.T) / net_od.shape[1]
    dffb = np.mean(net_od, axis=1)


    return (layer_2_dk,layer_2_db,layer_4_dk,layer_4_db,dffW,dffb,net_Loss)





def cnn_update(weights,dev,layer_output,alpha):
    
    layer_2_dk = dev.l_2_dk
    layer_2_db = dev.l_2_db
    layer_4_dk = dev.l_4_dk
    layer_4_db = dev.l_4_db
    dffW = dev.dff_W
    dffb = dev.dff_b
    
    net_layer_2_k = weights.net_l_2_k
    net_layer_2_b = weights.net_l_2_b
    net_layer_4_k = weights.net_l_4_k
    net_layer_4_b = weights.net_l_4_b
    ffW = weights.net_ff_W
    ffb = weights.net_ff_b
    
    layer_2_a = layer_output.l_2_a
    layer_3_a = layer_output.l_3_a
    layer_4_a = layer_output.l_4_a
    layer_5_a = layer_output.l_5_a
    concatenated = layer_output.l_concatenated

    #first convolutional layer
    for j in xrange(0,layer_2_a.shape[3]):
        net_layer_2_k[:,:,0,j] = net_layer_2_k[:,:,0,j] - alpha * layer_2_dk[:,:,0,j]
        net_layer_2_b[0,j] = net_layer_2_b[0,j] - alpha * layer_2_db[0,j]

    #second convolutional layer
    for j in xrange(0,layer_4_a.shape[3]):
        for i in xrange(0,layer_3_a.shape[3]):
            net_layer_4_k[:,:,i,j] = net_layer_4_k[:,:,i,j] - alpha * layer_4_dk[:,:,i,j]
        net_layer_4_b[0,j] = net_layer_4_b[0,j] - layer_4_db[0,j]

    #fully connected layer
    ffW = ffW - alpha * dffW
    ffb[:,0] = ffb[:,0] - alpha * dffb

    return (net_layer_2_k,net_layer_2_b,net_layer_4_k,net_layer_4_b,ffW,ffb)




def cnn_test(X,Y,para,weights):
    layer_2_a,layer_3_a,layer_4_a,layer_5_a,concatenated,net_output = cnn_ff(X,para,weights)
    
    predicted = net_output.argmax(axis=0)
    label = Y.argmax(axis=0)
    accuracy = (np.sum(predicted == label) + 0.) / label.shape[0]
    
    return accuracy




#------------------------------------------------------------------------------------------------
#loading training and testing data
X_train, y_train, X_val, y_val, X_test, y_test = load_dataset()

# num * dimension
#X_train = X_train.reshape(50000,28*28)
#X_test = X_test.reshape(10000,28*28)

X_train = X_train.transpose((2,3,0,1)).reshape((28,28,50000))
X_test = X_test.transpose((2,3,0,1)).reshape((28,28,10000))

temp = np.zeros(X_train.shape).astype(np.float32)
temp[:,:,:] = X_train[:,:,:]
X_train = temp

temp = np.zeros(X_test.shape).astype(np.float32)
temp[:,:,:] = X_test[:,:,:]
X_test = temp


Y_train = np.zeros((10,y_train.shape[0])).astype(np.float32)
for i in xrange(y_train.shape[0]):
    Y_train[y_train[i],i] = 1

Y_test = np.zeros((10,y_test.shape[0])).astype(np.float32)
for i in xrange(y_test.shape[0]):
    Y_test[y_test[i],i] = 1


#------------------------------------------------------------------------------------------------
#initialize the network
#this is a input-6c-2s-12c-2s-output Convolutional neural network

#specify parameters
layer_2_outputmaps = 6
layer_2_kernelsize = 5
layer_3_scale = 2
layer_4_outputmaps = 12
layer_4_kernelsize = 5
layer_5_scale = 2

alpha = 1

para = net_para(l_2_outputmaps=6,l_2_kernelsize=5,l_3_scale=2,l_4_outputmaps=12,l_4_kernelsize=5,l_5_scale=2)


print "initialization start"

start = time.time()

#second layer: first convolutional layer
inputmaps = 1
k_s = layer_2_kernelsize
mapsize = X_train.shape[0]
mapsize = mapsize - k_s + 1
fan_out = layer_2_outputmaps * k_s * k_s

net_layer_2_k = np.zeros((k_s,k_s,1,layer_2_outputmaps)).astype(np.float32)
net_layer_2_b = np.zeros((1,layer_2_outputmaps)).astype(np.float32)

for j in xrange(0,layer_2_outputmaps):
    fan_in = inputmaps * k_s * k_s
    net_layer_2_k[:,:,0,j] = ( np.random.uniform(0,1,(k_s, k_s)) - 0.5 ) * 2. * np.sqrt(6. / (fan_in + fan_out))


#third layer: first sub-sampling layer
inputmaps = layer_2_outputmaps
mapsize = mapsize / layer_3_scale
net_layer_3_b = np.zeros((1,inputmaps)).astype(np.float32)


#fourth layer: second convolutional layer
k_s = layer_4_kernelsize

mapsize = mapsize - k_s + 1
fan_out = layer_4_outputmaps * k_s * k_s

net_layer_4_k = np.zeros((k_s,k_s,inputmaps,layer_4_outputmaps)).astype(np.float32)
net_layer_4_b = np.zeros((1,layer_4_outputmaps)).astype(np.float32)

for j in xrange(0,layer_4_outputmaps):
    fan_in = inputmaps * k_s * k_s
    for i in xrange(0,inputmaps):
        net_layer_4_k[:,:,i,j] = ( np.random.uniform(0,1,(k_s, k_s)) - 0.5 ) * 2. * np.sqrt(6. / (fan_in + fan_out))


#fifth layer:  second sub-sampling layer
inputmaps = layer_4_outputmaps
mapsize = mapsize / layer_5_scale
net_layer_5_b = np.zeros((1,inputmaps)).astype(np.float32)


#output layer: fully connected layer
fvnum = mapsize * mapsize * inputmaps
onum = 10

net_ffb = np.zeros((onum,1)).astype(np.float32)
net_ffW = ( np.random.uniform(0,1,(onum, fvnum)).astype(np.float32) - 0.5 ) * 2. * np.sqrt(6. / (onum + fvnum))



weights = net_weights(net_l_2_k=net_layer_2_k,net_l_2_b=net_layer_2_b,net_l_3_b=net_layer_3_b,net_l_4_k=net_layer_4_k,net_l_4_b=net_layer_4_b,net_l_5_b=net_layer_5_b,net_ff_b=net_ffb,net_ff_W=net_ffW)


print "     initialization done"

times = time.time() - start
print "  initialization time (s): ", times


#------------------------------------------------------------------------------------------------
#train the network
print "                 "
print "training start"

num_epochs = 100
batch_size = 100
loss = np.zeros((1,100000))
counter = -1

test_acc = np.zeros((1,1000))

for ite in xrange(num_epochs):

    print "   at iteration ", ite+1, " of ", num_epochs
    
    
    index_random = np.random.permutation(range(X_train.shape[2]))
    num_batch = X_train.shape[2] / batch_size
    
    for i in xrange(num_batch):
        
        print "         at batch ", i+1, " of ", num_batch, "   at iteration ", ite+1, " of ", num_epochs
        
        current_batch_index = index_random[i*batch_size:(i+1)*batch_size]
        current_X_train = X_train[:,:,current_batch_index]
        current_Y_train = Y_train[:,current_batch_index]

        start = time.time()
        layer_2_a,layer_3_a,layer_4_a,layer_5_a,concatenated,net_output = cnn_ff(current_X_train,para,weights)

        layer_output = net_layer_output(l_2_a=layer_2_a,l_3_a=layer_3_a,l_4_a=layer_4_a,l_5_a=layer_5_a,l_concatenated=concatenated,net_l_output=net_output)
        times = time.time() - start
        print "             forward time (s): ", times

        start = time.time()
        layer_2_dk,layer_2_db,layer_4_dk,layer_4_db,dffW,dffb,net_loss = cnn_bp(layer_output,current_Y_train,weights,current_X_train)
        
        counter = counter + 1
        loss[0,counter] = net_loss
        

        layer_dev = net_dev(l_2_dk=layer_2_dk,l_2_db=layer_2_db,l_4_dk=layer_4_dk,l_4_db=layer_4_db,dff_W=dffW,dff_b=dffb)
        times = time.time() - start
        print "             backpropagate time (s): ", times

        start = time.time()
        net_layer_2_k,net_layer_2_b,net_layer_4_k,net_layer_4_b,ffW,ffb = cnn_update(weights,layer_dev,layer_output,alpha)

        weights.net_l_2_k = net_layer_2_k
        weights.net_l_2_b = net_layer_2_b
        weights.net_l_4_k = net_layer_4_k
        weights.net_l_4_b = net_layer_4_b
        weights.net_ff_W = ffW
        weights.net_ff_b = ffb
        times = time.time() - start
        print "             update time (s): ", times


    acc = cnn_test(X_test,Y_test,para,weights)
    print "    testing accuracy is ", acc


    test_acc[0,ite] = acc
    np.savetxt('loss_gpu.txt',loss)
    np.savetxt('acc_gpu.txt',test_acc)



np.savetxt('loss_gpu.txt',loss)
np.savetxt('acc_gpu.txt',test_acc)








